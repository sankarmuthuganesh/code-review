What is in the Zip.

*** If its just a keyword to be avoided, then it can be added through bug adder screen. If it involves complex logic, then the below process of gravity bug creation applies. ***


Gravity Bug Creation:
---------------------
UseFiles Folder:
----------------
Note: Place the downloaded framework files as per the package already present********** Important************.

1. An interface named GravityBug.java.
	- Every bug you create should implement this Interface.
BugCategory.java, Whatever bug created, its category should be set one among the categories in this file.
BugDetails.java, when a bug is found its details are set to this entity. Kindly set all the details.
FileEditor.java - It has methods that can be used to edit files with ease. It can be used for bug fixing logic if necessary.

Ok, Now you have placed all the files and created an new class implementing GravityBug.java

2. Two methods should be implemented, bugFinderLogic and bugFixLogic.
	bugFinderLogic - the parameter fileToAnalyse should be used and the method body should contain the logic to find the bug. And if bug is 
			 found, true is set as key to the return type map and value is the bug details. *For Reference - See the typical example in the Example and Test Folder.
	bugFixLogic - alter the code in the file for the correct solution, and set true as key to the returned map if changes have been made to the file
			and the value the line numbers that have been altered in the file.
3. For every bug creation you can create a class and repeat the above steps.

4. Please refer the docs in every file provided. It provides good clarity in creating bug.
5. Example and Test folder. --> Has a typical example of how to create a bug and test it. Refer it and make your own.

-----

Example and Testing Folder:
---------------------------
Example and Test folder. --> SampleBugLogic.java is the file you want to write.
		 	     Other two files are for testing the above logic written.
How to test your own...
Once you have created a logic, 
create an object for that class and pass it to the GravityBugConstruct -> findBugLogic and fixBugLogic. (Refer Test.java in Example and Test Folder)
	Provide Test File Path.
	Run the test file.
	It will find the bug and fix it according to you logic.
	If bug finding and bug fixing were successful and are according to your intentions you can proceed with the below.

Final Steps:
------------
Select the Classes where you have wrote the logic (ie., the classes implementing GravityBug interface only eg.,SampleBugLogic.java) and right click --> export --> choose jar --> type a jar name --> Finish.
Once the packing is finished, upload the jar to the bug adder site.
(The packed jar should contain only the Class(es) implementing the GravityBug interface. The other files from the downloaded zip can be excluded.
** In case the bug finding and fixing logics were complex and has dependent jars, pack the jar including dependent jars.
The uploaded jar will get reflected immediately when you analyze a story.(if your upload is successfull)

For reference a sample packed jar was extracted and placed in folder Exported Sample, if necessary extract and see what it contains.



